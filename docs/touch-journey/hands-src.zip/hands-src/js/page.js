/* page.js — assembles the journey and wires the two interactive figures.
   Scroll-based, because this is reading rather than a lesson. */

const $ = s => document.querySelector(s);
const ST = {vel:3, vel2:3, temp:32, rec:"ct", part:"finger", gateTouch:true, bond:"stranger",
  stim:"brush", claimsShown:false, claimGuess:.7, ctx:{consent:true,known:true,warned:true}};

/* Expand the two markup conventions used in journey.js:
     [ref:id]           -> superscript link to the reference list
     {{Wiki Page|text}} -> link to English Wikipedia                       */
const REF_ORDER = [];
function refNum(id){
  if(!REFS[id]) return null;
  let i = REF_ORDER.indexOf(id);
  if(i < 0){ REF_ORDER.push(id); i = REF_ORDER.length-1; }
  return i+1;
}
function md(s){
  if(!s) return "";
  return String(s)
    .replace(/\{\{([^|}]+)\|([^}]+)\}\}/g, (m,page,text) =>
      `<a class="wiki" href="https://en.wikipedia.org/wiki/${encodeURIComponent(page.trim().replace(/ /g,"_"))}"
        target="_blank" rel="noopener" title="Wikipedia: ${esc(page.trim())}">${text}</a>`)
    .replace(/\[ref:([a-z0-9]+)\]/g, (m,id) => {
      const n = refNum(id);
      return n ? `<a class="cite" href="#ref-${id}" title="${esc(REFS[id].a+" "+REFS[id].y)}">${n}</a>` : "";
    });
}

const paperCard = p => !p ? "" : `
  <div class="paper">
    <div class="who">${esc(p.who)} · ${p.y}</div>
    <div class="what">${esc(p.what)}</div>
    <div class="where">${esc(p.where)}</div>
    <div style="margin-top:7px"><a href="${p.u}" target="_blank" rel="noopener">open the paper →</a></div>
    <div class="grade">${esc(p.grade)}</div>
  </div>`;

const figure = (inner, cap) =>
  `<figure class="wide">${inner}${cap?`<div class="cap">${cap}</div>`:""}</figure>`;

function sceneFor(st){
  switch(st.scene){
    case "speed": return `
      <figure class="wide">
        <div class="controls">
          <label>how fast you stroke
            <input type="range" id="vel" min="0.3" max="30" step="0.1" value="${ST.vel}"
              aria-label="Stroking speed"></label>
          <b id="velv">${ST.vel.toFixed(1)} cm/s</b>
        </div>
        <div id="speedFig">${SCENES.speed(ST)}</div>
        <div class="cap">Curve shapes follow the published figure; the firing values are
          indicative rather than exact. The dot moves at the real speed.</div>
      </figure>`;
    case "warmth": return `
      <figure class="wide">
        <div class="controls">
          <label>speed
            <input type="range" id="vel2" min="0.3" max="30" step="0.1" value="${ST.vel2}"
              aria-label="Stroking speed"></label>
          <b id="vel2v">${ST.vel2.toFixed(1)} cm/s</b>
          <span style="display:flex;gap:8px">
            ${[18,32,42].map(t=>`<button class="pill" data-temp="${t}"
              aria-pressed="${ST.temp===t}">${t}°</button>`).join("")}
          </span>
        </div>
        <div id="warmFig">${SCENES.warmth(ST)}</div>
        <div class="cap">A simplified picture of two findings held together. The sweet spot
          is drawn as a region because that is how it behaves, not as a measured contour.</div>
      </figure>`;
    case "roads": return `
      <figure class="wide">
        <div class="controls">
          <button class="pill" id="sendBtn">send a touch →</button>
          <span id="sendOut" style="color:var(--ink3)">both signals leave the skin at the same instant</span>
        </div>
        <div id="roadsFig">${SCENES.roads(ST)}</div>
        <div class="cap">The animation runs in real time. A fast signal crosses in a few
          hundredths of a second; the slow one takes about a second. That gap is the
          finding, not an effect.</div>
      </figure>`;
    case "micro": return `
      <figure class="wide">
        <div class="controls"><span>touch the skin with</span>
          <button class="pill" data-stim="brush" aria-pressed="${ST.stim==="brush"}">a soft brush</button>
          <button class="pill" data-stim="sharp" aria-pressed="${ST.stim==="sharp"}">a sharp point</button></div>
        <div id="microFig">${SCENES.micro(ST)}</div>
        <div class="cap">Spike trains are illustrative. The contrast is the real one: these
          fibres were told apart from pain fibres precisely by answering a gentle stimulus
          and not a sharp one.</div>
      </figure>`;
    case "claims": return `
      <figure class="wide">
        <div id="claimsCtl">${ST.claimsShown ? `<div class="controls">
            <button class="pill" id="claimsHide">hide the answers again</button></div>`
          : `<div class="controls">
            <span>before you look — how well supported is <b style="font-family:Fraunces,serif">“touch measurably raises oxytocin”</b>?</span>
            <input type="range" id="claimGuess" min="0" max="1" step=".01" value="${ST.claimGuess}"
              aria-label="Your estimate">
            <button class="pill" id="claimsShow">show the answers</button></div>`}</div>
        <div id="claimsFig">${SCENES.claims(ST)}</div>
        <div class="cap">Positions are a judgement about how much weight to give each claim,
          not measured effect sizes. Arranged so the shape of the field is visible.</div>
      </figure>`;
    case "context": return `
      <figure class="wide">
        <div class="controls"><span>everything physical stays the same — change only:</span>
          ${CTX.map(c=>`<button class="pill" data-ctx="${c.id}"
            aria-pressed="${ST.ctx[c.id]}">${esc(c.n)}</button>`).join("")}</div>
        <div id="ctxFig">${SCENES.context(ST)}</div>
        <div class="cap">Illustrative, not measured — no study assigns these labels. It is
          here because the point is hard to feel from a sentence and easy to feel from a
          switch.</div>
      </figure>`;
    case "skin": return `
      <figure class="wide"><div id="skinFig">${SCENES.skin(ST)}</div>
        <div class="cap">Depths and shapes are schematic. Tap a receptor to read what it does.</div></figure>`;
    case "acuity": return `
      <figure class="wide">
        <div class="controls"><span>where on the body</span>
          ${PARTS.map(q=>`<button class="pill" data-part="${q.id}"
            aria-pressed="${ST.part===q.id}">${esc(q.n)}</button>`).join("")}</div>
        <div id="acuFig">${SCENES.acuity(ST)}</div>
        <div class="cap">Drawn to scale on screen. Values are the classic Weinstein figures,
          widely reproduced — the ranking is solid, the exact millimetres less so.</div>
      </figure>`;
    case "gate": return `
      <figure class="wide">
        <div class="controls">
          <button class="pill" id="gateBtn" aria-pressed="${ST.gateTouch}">${ST.gateTouch?"hand on the skin":"no touch"}</button>
          <span id="gateHint" style="color:var(--ink3)">${ST.gateTouch?"tap to take the hand away":"tap to put the hand back"}</span></div>
        <div id="gateFig">${SCENES.gate(ST)}</div>
        <div class="cap">The original 1965 drawing, much simplified. Sixty years of revision
          have complicated the mechanism without overturning the central claim.</div>
      </figure>`;
    case "topography": return `
      <figure class="wide">
        <div class="controls"><span>who is touching you</span>
          ${BONDS.map(z=>`<button class="pill" data-bond2="${z.id}"
            aria-pressed="${ST.bond===z.id}">${esc(z.n)}</button>`).join("")}</div>
        <div id="topoFig">${SCENES.topography(ST)}</div>
        <div class="cap">The zones are a simplification of the published maps; the
          area-against-bond relationship on the right is the paper's actual finding.</div>
      </figure>`;
    case "claims": return `
      <figure class="wide"><div>${SCENES.claims()}</div>
        <div class="cap">Positions are a judgement about how much weight to put on each
          claim, not measured effect sizes. Arranged so the shape of the field is visible.</div></figure>`;
    case "revisions": return `
      <figure class="wide">
        <div class="cards" id="cards">${REVISIONS.map((r,i)=>`
          <button class="flip" data-i="${i}" aria-pressed="false">
            <div class="side"><span>what we said</span>${esc(r.old)}</div>
            <div class="tap">tap for the correction</div>
          </button>`).join("")}</div>
        <div class="cap">Four corrections from the last decade. Tap each card to turn it over.</div>
      </figure>`;
    default:
      return figure(SCENES[st.scene](ST));
  }
}

$(".wrap").innerHTML = `
<header class="hero">
  <div class="eyebrow">${esc(HERO.eyebrow)}</div>
  <h1>${HERO.title}</h1>
  <div class="stand">${HERO.stand}</div>
</header>

<section class="about" aria-label="About this page">
  ${ABOUT.map(a=>`<div class="ab"><div class="k">${esc(a.k)}</div><div class="v">${md(a.v)}</div></div>`).join("")}
</section>

<nav class="toc" aria-label="Contents">${STOPS.map(s=>
  `<a href="#${s.id}" data-t="${s.id}">${esc(s.nav)}</a>`).join("")}
  <a href="#refs" data-t="refs" style="margin-top:8px">References</a></nav>

${STOPS.map(s=>`
${s.part?`<div class="part">${esc(s.part)}</div>`:""}
<section class="stop" id="${s.id}">
  <div class="year">${esc(s.year)}</div>
  <h2>${esc(s.title)}</h2>
  <div class="lead">${md(s.lead)}</div>
  ${s.src?`<div class="src"><span class="lbl">The research</span>${md(s.src.line)}</div>`:""}
  ${sceneFor(s)}
  <div class="body">${md(s.body)}</div>
  ${s.hands?`<div class="hands"><div class="t">For your hands</div><p>${md(s.hands)}</p></div>`:""}
</section>`).join("")}

<section class="close">
  <h2>What to actually do with this</h2>
  <p class="lead" style="max-width:34rem">Ten things, in rough order of how confident you
    can be about them.</p>
  <ul class="rules">${RULES.map(r=>`<li><b>${esc(r.t)}</b><br>${esc(r.d)}</li>`).join("")}</ul>

  <div class="reading">
    <h3>If you want to go further</h3>
    ${FURTHER.map(f=>{const r=REFS[f.id];
      return `<div><a class="n" href="${r.u}" target="_blank" rel="noopener">${esc(r.a.split(",")[0])} et al. (${r.y})</a>
        — ${esc(r.d||f.d)}</div>`;}).join("")}
  </div>

  <div class="reading" id="refs">
    <h3>References</h3>
    <p style="font-size:15px;color:var(--ink3);margin-bottom:6px">In the order they are cited above.
      Every one is linked; several are free to read in full.</p>
    <ol class="refs">${REF_ORDER.map(id=>{const r=REFS[id];
      return `<li id="ref-${id}"><span class="au">${esc(r.a)}${r.y?" ("+r.y+")":""}</span>
        <a href="${r.u}" target="_blank" rel="noopener">${esc(r.t)}</a>
        <span class="jo">${esc(r.j)}</span></li>`;}).join("")}</ol>
  </div>

  <p class="foot">Assembled in 2026 from the literature as it stood. This page summarises
    published research for people who work with touch. It is not medical advice, it does not
    describe a technique, and it cannot tell you what the person in front of you wants. Where
    researchers disagree, it says so — that is not hedging, it is the current state of a young
    field still arguing productively with itself.</p>
</section>`;

/* ── the two interactive figures ───────────────────────────────── */
function wire(){
  const v=$("#vel");
  if(v) v.oninput=()=>{ ST.vel=+v.value; $("#velv").textContent=ST.vel.toFixed(1)+" cm/s";
    $("#speedFig").innerHTML=SCENES.speed(ST); stroke(); };
  const v2=$("#vel2");
  if(v2) v2.oninput=()=>{ ST.vel2=+v2.value; $("#vel2v").textContent=ST.vel2.toFixed(1)+" cm/s";
    $("#warmFig").innerHTML=SCENES.warmth(ST); };
  document.querySelectorAll("[data-temp]").forEach(b=>b.onclick=()=>{
    ST.temp=+b.dataset.temp;
    document.querySelectorAll("[data-temp]").forEach(z=>
      z.setAttribute("aria-pressed", +z.dataset.temp===ST.temp));
    $("#warmFig").innerHTML=SCENES.warmth(ST); });
  const sb=$("#sendBtn");
  if(sb) sb.onclick=()=>sendTouch();
  document.querySelectorAll("[data-stim]").forEach(b=>b.onclick=()=>{
    ST.stim=b.dataset.stim;
    document.querySelectorAll("[data-stim]").forEach(z=>
      z.setAttribute("aria-pressed", z.dataset.stim===ST.stim));
    $("#microFig").innerHTML=SCENES.micro(ST); });
  const cg=$("#claimGuess");
  if(cg) cg.oninput=()=>{ ST.claimGuess=+cg.value; $("#claimsFig").innerHTML=SCENES.claims(ST); };
  const swapClaims=v=>{
    ST.claimsShown=v;
    $("#claimsCtl").innerHTML = v
      ? `<div class="controls"><button class="pill" id="claimsHide">hide the answers again</button></div>`
      : `<div class="controls">
          <span>before you look — how well supported is <b style="font-family:Fraunces,serif">“touch measurably raises oxytocin”</b>?</span>
          <input type="range" id="claimGuess" min="0" max="1" step=".01" value="${ST.claimGuess}"
            aria-label="Your estimate">
          <button class="pill" id="claimsShow">show the answers</button></div>`;
    $("#claimsFig").innerHTML=SCENES.claims(ST);
    wire();
  };
  const cs=$("#claimsShow"); if(cs) cs.onclick=()=>swapClaims(true);
  const ch=$("#claimsHide"); if(ch) ch.onclick=()=>swapClaims(false);
  document.querySelectorAll("[data-ctx]").forEach(b=>b.onclick=()=>{
    ST.ctx[b.dataset.ctx]=!ST.ctx[b.dataset.ctx];
    b.setAttribute("aria-pressed", ST.ctx[b.dataset.ctx]);
    const c=CTX.find(z=>z.id===b.dataset.ctx);
    b.textContent = ST.ctx[b.dataset.ctx] ? c.n : c.off;
    $("#ctxFig").innerHTML=SCENES.context(ST); });
  document.querySelectorAll("[data-rec]").forEach(g=>g.onclick=()=>{
    ST.rec=g.dataset.rec; $("#skinFig").innerHTML=SCENES.skin(ST); wire(); });
  document.querySelectorAll("[data-part]").forEach(b=>b.onclick=()=>{
    ST.part=b.dataset.part;
    document.querySelectorAll("[data-part]").forEach(z=>
      z.setAttribute("aria-pressed", z.dataset.part===ST.part));
    $("#acuFig").innerHTML=SCENES.acuity(ST); });
  const gb=$("#gateBtn");
  if(gb) gb.onclick=()=>{ ST.gateTouch=!ST.gateTouch;
    gb.setAttribute("aria-pressed",ST.gateTouch);
    gb.textContent = ST.gateTouch ? "hand on the skin" : "no touch";
    const gh=$("#gateHint");
    if(gh) gh.textContent = ST.gateTouch ? "tap to take the hand away" : "tap to put the hand back";
    $("#gateFig").innerHTML=SCENES.gate(ST); };
  const setBond=id=>{ ST.bond=id;
    document.querySelectorAll("[data-bond2]").forEach(z=>
      z.setAttribute("aria-pressed", z.dataset.bond2===ST.bond));
    $("#topoFig").innerHTML=SCENES.topography(ST); wire(); };
  document.querySelectorAll("[data-bond2]").forEach(b=>b.onclick=()=>setBond(b.dataset.bond2));
  document.querySelectorAll("[data-bond]").forEach(r=>r.onclick=()=>setBond(r.dataset.bond));
  document.querySelectorAll(".flip").forEach(b=>b.onclick=()=>{
    const i=+b.dataset.i, r=REVISIONS[i], on=b.getAttribute("aria-pressed")==="true";
    b.setAttribute("aria-pressed", !on);
    b.innerHTML = on
      ? `<div class="side"><span>what we said</span>${esc(r.old)}</div>
         <div class="tap">tap for the correction</div>`
      : `<div class="side"><span>what we say now</span>${esc(r.neu)}</div>
         <div class="tap">${esc(r.src)}</div>`;
  });
}

/* Send one touch up both roads, in real time. A fast fibre crosses a forearm
   in a few hundredths of a second; the slow one takes about a second. Nothing
   here is sped up or slowed down — the gap is the point. */
let sendRaf=null;
function sendTouch(){
  const fp=document.getElementById("fastPath"), sp=document.getElementById("slowPath");
  const fd=document.getElementById("fastDot"), sd=document.getElementById("slowDot");
  const fl=document.getElementById("fastLand"), sl=document.getElementById("slowLand");
  const out=$("#sendOut");
  if(!fp||!sp||!fd||!sd) return;
  if(sendRaf) cancelAnimationFrame(sendRaf);
  if(matchMedia("(prefers-reduced-motion:reduce)").matches){
    [fd,sd,fl,sl].forEach(el=>el&&el.setAttribute("opacity","1"));
    if(out) out.textContent="the slow signal lands about a second after the fast one";
    return;
  }
  const FL=fp.getTotalLength(), SL=sp.getTotalLength();
  const FAST=0.06, SLOW=1.0;                       // seconds, as in a real forearm
  [fl,sl].forEach(el=>el&&el.setAttribute("opacity","0"));
  const t0=performance.now();
  const step=now=>{
    const t=(now-t0)/1000;
    const f=Math.min(t/FAST,1), s=Math.min(t/SLOW,1);
    const pf=fp.getPointAtLength(FL*f), ps=sp.getPointAtLength(SL*s);
    fd.setAttribute("opacity", f<1?"1":"0.3"); fd.setAttribute("cx",pf.x); fd.setAttribute("cy",pf.y);
    sd.setAttribute("opacity", s<1?"1":"0.3"); sd.setAttribute("cx",ps.x); sd.setAttribute("cy",ps.y);
    if(f>=1&&fl) fl.setAttribute("opacity","1");
    if(s>=1&&sl) sl.setAttribute("opacity","1");
    if(out) out.textContent = s<1
      ? `fast signal arrived · the slow one is still travelling — ${(SLOW-t).toFixed(1)}s to go`
      : "the slow signal landed about a second after the fast one";
    if(f<1||s<1) sendRaf=requestAnimationFrame(step); else sendRaf=null;
  };
  sendRaf=requestAnimationFrame(step);
}

/* the dot travels at the true speed — 15 cm of forearm */
let raf=null;
function stroke(){
  if(raf) cancelAnimationFrame(raf);
  if(matchMedia("(prefers-reduced-motion:reduce)").matches) return;
  const step=ts=>{
    const el=document.getElementById("stroker");
    if(!el){ raf=null; return; }
    const secs=15/ST.vel, L=92, span=860-92-210+120-80;
    const u=((ts/1000)/secs)%2, f=u<1?u:2-u;
    el.setAttribute("cx", L+40+f*span);
    raf=requestAnimationFrame(step);
  };
  raf=requestAnimationFrame(step);
}

/* contents highlighting */
const links=[...document.querySelectorAll(".toc a")];
const io=new IntersectionObserver(es=>{
  es.forEach(e=>{ if(e.isIntersecting)
    links.forEach(a=>a.classList.toggle("on", a.dataset.t===e.target.id)); });
},{rootMargin:"-45% 0px -50% 0px"});
STOPS.forEach(s=>{ const el=document.getElementById(s.id); if(el) io.observe(el); });

wire(); stroke();

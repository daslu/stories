/* journey.js — everything the page says.
 *
 * Two small markup conventions used inside the prose strings:
 *   [ref:id]           → a superscript link down to the reference list
 *   {{Wiki Page|text}} → a link to English Wikipedia
 * Both are expanded by md() in page.js.
 *
 * Voice: talking to a skilled practitioner who is not a scientist. Warm,
 * plain, specific. Every stop names its source in the first breath. */

const HERO = {
 eyebrow:"A reading journey for hands-on practitioners",
 title:"Touch is not one sense",
 stand:`Skin carries at least two separate systems, and they are not sending the same
   message. One tells you <em>what</em> you are touching. The other seems to be there to
   register being touched <em>affectionately</em> — found by accident, confirmed by a man
   who had lost the ordinary sense of touch, and it turns out to have a preferred speed.
   What follows is what we found reading our way through it: what each system is for, what
   touch does to pain and to relationships, and which of the popular claims we could not
   get to stand up.`
};

const ABOUT = [
 {k:"What this is",
  v:`A plain-language walk through the research on touch — the
    {{Somatosensory system|sense}}, not the technique. Twelve short stops, about thirty
    minutes, with figures you can operate rather than only look at.`},
 {k:"Who it is for",
  v:`Anyone whose work involves putting hands on other people: massage therapists,
    bodyworkers, physiotherapists, osteopaths, nurses, midwives, somatic and trauma
    practitioners. <b>No science background is assumed</b> — we did not begin with much
    of one either.`},
 {k:"How it is sourced",
  v:`Every claim here points to a named paper, cited at the top of its section and listed
    in full at the bottom — so you can go and check where we have read it wrong. Where
    researchers disagree, and here they disagree a good deal, we have tried to say so rather
    than pick a side. It is not medical advice and not a technique manual.`}
];

const STOPS = [

{id:"two", nav:"Two roads", part:"Part one · the territory", year:"The idea",
 title:"There are two ways of being touched",
 lead:`Everything else here follows from one thing: touch is not a single sense. Two
   separate kinds of nerve fibre leave the skin at the same instant, travelling at very
   different speeds, and they are not carrying the same message.`,
 src:{line:`This first stop is the shared framework rather than a single study — it is
   drawn from the review by McGlone, Wessberg & Olausson (2014) [ref:mcglone14], which is
   also the best single thing to read after this page.`},
 scene:"roads",
 body:`<p>The <b>fast road</b> is the one most people mean by touch. Thick fibres wrapped in
   {{Myelin|myelin}}, an insulating sheath that lets a signal race along at tens of metres
   per second. They are superb at <b>what and where</b> — the exact spot, the texture, the
   pressure, the edge of the object in your hand. This is the system that lets you find a
   coin in your pocket without looking.</p>
  <p>The <b>slow road</b> is the surprise. Thin fibres with no insulation, a signal ambling
   along at about one metre per second — so slow that when someone strokes your forearm,
   that part of the message arrives something like <b>a second behind</b> the rest. They are
   poor at what and where. They are, apparently, in the business of <b>how it feels</b>.</p>
  <p>Those two colours — blue for the fast road, clay for the slow one — mean the same
   thing in every figure from here on. Nothing below assumes you have met any of this
   before.</p>`,
 hands:`If you have ever wondered why a client goes quiet a beat <em>after</em> your hands
   land rather than as they land, there is a real signal running about a second behind the
   obvious one.`},

{id:"organ", nav:"The organ", year:"Where it happens",
 title:"You are working on a sense organ, not a covering",
 lead:`Skin is usually described as a barrier. It is also the largest sensory surface you
   have, and the fast road alone arrives on four different kinds of receptor, each answering
   to something different.`,
 src:{line:`Standard anatomy rather than a finding [ref:standring] — the classification of
   {{Mechanoreceptor|mechanoreceptors}} below is textbook material, and each type links to
   its Wikipedia entry if you want the detail.`},
 scene:"skin",
 body:`<p>Tap any receptor in the diagram. Two live near the surface and handle fine, quick
   things: {{Merkel nerve ending|Merkel cells}} for <b>edges and texture</b>, and
   {{Tactile corpuscle|Meissner corpuscles}} for <b>slip</b> — the receptor that tells you a
   glass is sliding out of your grip before you consciously notice.</p>
  <p>Two sit deeper and handle slower, coarser things. {{Bulbous corpuscle|Ruffini endings}}
   register <b>stretch</b> across the skin, part of how you know where your hand is without
   looking. {{Lamellar corpuscle|Pacinian corpuscles}} register <b>fast vibration</b>, which
   is how you feel the texture of a surface through the end of a tool rather than through
   your fingertips.</p>
  <p>And then the fifth kind: {{Free nerve ending|bare nerve endings}} with no capsule at
   all, wandering in the hairy skin. Those are the slow road, and the next four stops are
   about them.</p>`,
 hands:`When you change from a fingertip to a flat palm, from gliding to holding, from still
   to vibrating, you are not adjusting an intensity. You are moving between different
   receptors with different jobs.`},

{id:"acuity", nav:"How fine", year:"How fine",
 title:"Your fingertips are twenty times sharper than your back",
 lead:`How close together can two points be before skin stops feeling them as two? The
   answer varies across the body by more than twenty-fold — and the conclusion people
   usually draw from that is wider than the measurement allows.`,
 src:{line:`The numbers everyone quotes come from Weinstein's 1968 survey [ref:weinstein68].
   The test itself has been questioned for years as a measure of how finely you can feel [ref:tong13] — the
   ranking across the body is solid, the exact millimetres softer than they look.`},
 scene:"acuity",
 body:`<p>Pick a body part and look at the gap drawn to scale. On a <b>fingertip</b> the two
   dots have to come within two or three millimetres before they merge into one. On the
   <b>back</b> they can be nearly four centimetres apart and still feel like a single touch.
   This is {{Two-point discrimination|two-point discrimination}}, and it tracks how densely
   the fast receptors are packed.</p>
  <p>It is tempting to conclude from this that precision on a back is pointless. That would
   be over-reading a very narrow measurement, in at least three ways. <b>Locating</b> a
   single contact is generally more accurate than telling two apart, so a person can often
   say roughly where your hand is even where they could not resolve two touches. <b>Pressure
   reaches past the skin</b> — muscle, fascia and joints have their own sensory supply, and
   where you press changes what you are pressing on whatever the skin can resolve. And the
   precision may matter most <b>to you</b>: feeling your way is information travelling to you, the
   practitioner, and your fingertips resolve at two or three millimetres.</p>
  <p>What the number does tell you is narrower and still worth having: do not expect fine
   surface detail on a back to be <em>perceived</em> as detail by the person receiving it.
   And treat the exact figures gently — people can sometimes report "two" when both points
   are in the same place, which suggests the task picks up cues besides spacing.</p>`,
 hands:`Try it on yourself with two pencil tips or a bent paperclip. Fingertip, forearm,
   back. Then have someone touch one spot on your back and point to where you think it was —
   you will usually be closer than the two-point figure would suggest.`},

{id:"found", nav:"Found", part:"Part two · the second system", year:"1999",
 title:"Someone put a needle in a nerve and listened",
 lead:`The second road was found by a group in Gothenburg who were not looking for it. The
   technique is {{Microneurography|microneurography}}, and it is exactly as unlikely as it
   sounds: a very fine electrode placed into a nerve in a fully awake person, listening to
   single fibres while their skin is touched.`,
 src:{line:`Vallbo, Olausson & Wessberg (1999) [ref:vallbo99]. Not disputed — this is the
   discovery, and it has held for twenty-five years.`},
 scene:"micro",
 body:`<p>Recording from forearm skin, they kept finding fibres that made no sense. They were
   {{Group C nerve fiber|unmyelinated}} — the thin, slow kind everyone associated with pain
   and temperature — but they responded happily to a soft brush, and hardly at all to
   anything sharp.</p>
  <p>Of 38 units they picked for answering to gentle pressure on the skin, <b>27 were this
   low-threshold kind</b>. That ratio is not a count of how common they are — the units were chosen for
   responding to light touch in the first place. What tells you these fibres are not rare is
   a separate observation: the team reported running into them about as often as the classic
   fast ones.</p>
  <p>The title of the paper is the whole finding: unmyelinated fibres make up a
   <b>second system</b> for coding touch in human hairy skin. What that system was
   <em>for</em> was completely open.</p>`,
 hands:`These fibres are called <b>CT afferents</b> — C for the slow, unmyelinated kind — the ones with no
   insulating sheath — and T for touch. That is the term you will meet everywhere else, and this is where it comes
   from.`},

{id:"patient", nav:"The proof", year:"2002",
 title:"The man who could not feel touch, and felt it anyway",
 lead:`A second system is a nice idea, but how would you ever separate it from the first?
   The answer arrived in the form of a patient who had lost the fast road entirely.`,
 src:{line:`Olausson and colleagues (2002) [ref:olausson02]. Strong evidence, and a single
   case — you cannot arrange for a second patient.`},
 scene:"patient",
 body:`<p>A rare nerve disease had destroyed his large, insulated fibres. On any standard test
   he had no sense of touch on his body: he could not feel a poke, could not say where he
   had been touched, could not feel vibration. The fast road was gone.</p>
  <p>Then they stroked his forearm softly with a brush. He <b>felt something</b> — faint,
   hard to locate, and pleasant. And when they scanned his brain, the signal was not arriving
   at the usual place. It was lighting up the {{Insular cortex|insula}}, a region that deals
   with how the body feels from the inside: hunger, warmth, breath, discomfort.</p>
  <p>This is the study that turned an anatomical curiosity into a claim about experience.
   The slow road does not just exist. It goes somewhere <b>different</b>, and somewhere with
   more in common with emotion than with the map of your skin.</p>`,
 hands:`Affectionate touch is not a gentler version of informative touch. On this evidence
   it takes a different road and arrives somewhere else in the brain.`},

{id:"speed", nav:"A speed", year:"2009",
 title:"And it has a favourite speed",
 lead:`If these fibres were built for being stroked, you would expect them to care about how
   fast. They do — and it is not the fastest, and it is not the slowest.`,
 src:{line:`Löken and colleagues (2009) [ref:loken09]. Widely replicated as a group average;
   individuals vary more than the tidy curve suggests, which part four returns to.`},
 scene:"speed",
 body:`<p>They brushed people's forearms at five speeds while listening to single fibres,
   then asked how pleasant each stroke felt. The fast fibres did the sensible thing: the
   quicker the brush, the harder they fired. Speed in, speed out.</p>
  <p>The slow fibres did something more interesting. They fired hardest at <b>middling
   speeds</b>, around one to ten centimetres a second, and less at both extremes. Drag the
   dial and watch the shape. It is a hill, not a ramp.</p>
  <p>And how pleasant people rated it made the same hill. The speeds that lit up these fibres
   were the speeds people liked, and this range is often described as the speed of a caress.
   Worth a caveat that is easy to lose: when spontaneous stroking has actually been measured,
   it tends to run somewhat <b>faster</b> than the tuning peak, even though people stroke
   more slowly the closer they feel to the person. The hill is real. "This is exactly how
   humans naturally caress" is a tidier story than the measurements support.</p>`,
 hands:`The dot moves at the real speed. Watch it rather than the curve, then try matching it
   with your own hand on your forearm. That is what the research is describing.`},

{id:"warm", nav:"And a warmth", year:"2014",
 title:"It also wants you to be warm",
 lead:`A second tuning, and the one most likely to change what you actually do. These fibres
   are fussy about temperature, and the temperature they want is skin.`,
 src:{line:`Ackerley and colleagues (2014) [ref:ackerley14]. Well supported, and a small
   study — as all microneurography is.`},
 scene:"warmth",
 body:`<p>They repeated the stroking experiment at different temperatures. The fibres
   responded best to a brush at about <b>32 degrees</b> — neutral skin temperature. Not warm.
   Not cool. The temperature of another person.</p>
  <p>And the ratings followed. People found <b>every speed</b> more pleasant at skin
   temperature than at 18 degrees or at 42 degrees. Get the warmth wrong and the speed cannot
   rescue it.</p>
  <p>Try the two together in the panel. The sweet spot is a small region, not a line, and
   both dimensions have to be right to land in it.</p>`,
 hands:`Cold hands are not merely unpleasant, they are the wrong stimulus. So is oil straight
   from a cool bottle, and so is a treatment room a couple of degrees under. This is the
   cheapest change on this page.`},

{id:"pain", nav:"Pain", part:"Part three · what touch does", year:"1965 onward",
 title:"Touch turns pain down, and company turns it down further",
 lead:`The oldest practical claim about touch, and one of the better supported. Rubbing a
   banged elbow is not superstition; there is a mechanism, and it was proposed sixty years
   ago.`,
 src:{line:`Melzack & Wall's {{Gate control theory of pain|gate control theory}} (1965)
   [ref:melzack65], then Coan, Schaefer & Davidson (2006) [ref:coan06] and Goldstein and
   colleagues (2018) [ref:goldstein18]. The framework is one of the field’s starting points, and much revised since; the
   handholding studies are small and replicated in direction.`},
 scene:"gate",
 body:`<p>The idea was that pain signals have to pass through a <b>gate</b> in the spinal
   cord on their way up, and that fast touch fibres arriving from the same patch of skin can
   partly close it. Signals coming <em>down</em> from the brain — attention, expectation,
   mood — can open or close it too.</p>
  <p>The details have been revised many times in sixty years. The central claim has held:
   <b>touch and pain are not independent channels</b>, and one turns the other up or down before
   either reaches awareness.</p>
  <p>Then there is who is doing the touching. When women anticipating an electric shock held
   someone's hand, the threat response in the brain was reduced — <b>less by a stranger's
   hand than by their husband's</b>, and the better they rated the marriage, the larger the
   effect. Later work found that handholding during pain came with increased coupling between
   the two people's brain activity, and that the more empathic the partner, the more the pain
   went down.</p>`,
 hands:`Contact can genuinely reduce pain, and it is not only about the contact — the same
   hand does more when it belongs to someone the person trusts. That is an argument for the
   relationship being part of the treatment rather than around it.`},

{id:"where", nav:"Where", year:"2015",
 title:"Everyone carries a map of who may touch them where",
 lead:`Not a metaphor either. Ask people to shade in which parts of their body a given person
   is allowed to touch, and something very orderly comes out.`,
 src:{line:`Suvilehto and colleagues (2015) [ref:suvilehto15]. Large and cross-cultural, and
   entirely self-report — maps of what people say they would allow, which is not the same as
   what happens.`},
 scene:"topography",
 body:`<p><b>1,368 people across five countries</b> did exactly that, for everyone from a
   partner to a stranger. The maps were remarkably consistent, and the headline finding is
   almost embarrassingly simple: <b>the total area a person is allowed to touch
   tracks the strength of the emotional bond</b>. Cultural differences were
   minor.</p>
  <p>Hands are permitted to nearly everyone. The area expands outward from there as the
   relationship closes, and for a stranger most of the body is off limits. The regions people
   guard most closely are also the regions they rate as most pleasurable to be touched on.</p>
  <p>You occupy an unusual position on that map. As a practitioner you are given access it
   reserves for the people we are closest to — by agreement, in a role, for a purpose. That is a real thing to
   hold carefully, and it is why consent in this work is not a formality.</p>`,
 hands:`Your hands are on territory that, for this person, is normally reserved. Saying what
   you are about to do before you do it is not politeness. It is how the map gets redrawn
   safely.`},

{id:"claims", nav:"How sure", year:"The evidence",
 title:"How sure can we be about any of this?",
 lead:`Touch research makes a lot of claims and they are not equally supported. Here they are
   sorted honestly, because the strong ones get less airtime than the shaky ones.`,
 src:{line:`This one figure is a judgement rather than any single paper's result — a reading
   of the literature cited throughout, leaning on Kidd, Devine & Walker's review
   [ref:kidd23] for the stress claims and Moyer and colleagues' meta-analysis [ref:moyer11]
   for the {{Cortisol|cortisol}} one.`},
 scene:"claims",
 body:`<p>Notice the shape of it. The best-supported claims are the <b>simplest and most
   physical</b>: contact reduces pain, {{Kangaroo care|skin-to-skin contact}} steadies
   newborns. The weakest are the ones about <b>hormones</b> — the {{Oxytocin|oxytocin}} and
   cortisol stories that circulate most confidently in training rooms are the ones the
   evidence supports least well.</p>
  <p>That is not an accident. Subjective outcomes are easy to measure and to move; blood
   hormones are hard to measure, vary enormously between people and across a day, and rarely
   shift as neatly as the story requires. When you hear a claim about touch and a named
   hormone, treat it as the least secure thing in the sentence.</p>`,
 hands:`You do not need the hormone claims. The evidence you actually have — pain, comfort,
   distress, sleep in newborns — is stronger, more directly about what people come to you
   for, and much harder to argue with.`},

{id:"wrong", nav:"Corrections", part:"Part four · being honest about it", year:"2012–2023",
 title:"Four things this field has had to take back",
 lead:`Everything in part two is a decade old or more, and parts of it have been revised. A
   practitioner quoting the 2014 version is now quoting something the researchers have moved
   on from.`,
 src:{line:`Six papers between 2021 and 2023, named on the cards: Watkins [ref:watkins21],
   Case [ref:case21], Ali [ref:ali23], Bendas [ref:bendas21], Crucianelli [ref:crucianelli22]
   and — the largest — Schirmer, Croy & Ackerley [ref:schirmer23], a review by researchers
   inside the field checking their own published work.`},
 scene:"revisions",
 body:`<p>None of these demolish the story. They complicate it in ways that mostly make it
   <b>more</b> useful, and they are worth knowing so that you are not the last person in the
   room still saying the old version.</p>
  <p>The fourth is the largest and the least comfortable. Going through the literature, the
   authors found that of the papers using the phrase "{{Affective touch|affective touch}}",
   only <b>34%</b> even mention these fibres. A nerve fibre and a human experience had quietly
   become the same word, and they are not the same thing.</p>`,
 hands:`When you explain your work, describe the <b>touch</b> — slow, light, warm, moving, on
   a forearm — rather than claiming to activate a named nerve fibre. The first is accurate and
   checkable; the second goes further than anyone can currently support.`},

{id:"meaning", nav:"Meaning", year:"Now",
 title:"The fibre is not the feeling",
 lead:`The most useful correction of all, and it comes from within the research rather than
   from its critics.`,
 src:{line:`Sailer & Leknes (2022) [ref:sailer22] and Schirmer, Croy & Schweinberger (2022)
   [ref:schirmer22]. Position pieces rather than experiments — arguments about how to read
   the evidence, from people who generated much of it.`},
 scene:"context",
 body:`<p>The same stroke, at the same speed and the same temperature, is not the same
   experience depending on who is doing it, whether you consented, what happened last time,
   and what you believe it is for. One paper's title puts it plainly: <b>meaning makes touch
   affective</b>. The other argues that social touch is better understood as a <b>tool</b>
   people use to do something to each other than as a signal being transmitted.</p>
  <p>That is not a demotion of the nerve fibres. It is a description of where they sit. They
   look like a <b>doorway</b> — a channel well suited to carrying this kind of contact. What
   comes through the doorway is decided by everything else.</p>
  <p>Which is, if you think about it, what a good practitioner already knows. The biology
   has caught up with the room.</p>`,
 hands:`Speed and warmth are worth getting right, and they are the smaller half. Consent,
   predictability, and whether the person wanted to be touched by <em>you</em> are doing more
   work than any number on this page.`}
];

const REVISIONS = [
 {old:"CT fibres are found only in hairy skin. There are none in the palm.",
  neu:"A few of them have now been found in the hairless skin of the palm and fingers too. Fewer, not none — and pleasant touch is processed differently there rather than being absent.",
  src:"Watkins et al. 2021"},
 {old:"Pleasant touch means slow stroking. That is what the system is for.",
  neu:"Sustained, firmer contact is pleasant too. In one study static touch was preferred over stroking at the wrong speed — though optimal-speed stroking still won overall.",
  src:"Case et al. 2021 · Ali et al. 2023"},
 {old:"The tuning curve is the human response to touch speed.",
  neu:"It is a group average. Individuals vary considerably, and how quickly people get used to repeated touch differs person to person. The hill is real; your client's hill may sit elsewhere.",
  src:"Bendas et al. 2021 · Crucianelli et al. 2022"},
 {old:"“Affective touch” and “CT afferents” describe the same thing.",
  neu:"They have been used interchangeably without warrant. Only about a third of affective-touch papers mention these fibres at all. One is a nerve; the other is an experience.",
  src:"Schirmer, Croy & Ackerley 2023"}
];

/* evidence strength, hand-placed on a 0–1 scale */
const CLAIMS = [
 {t:"Skin-to-skin contact reduces newborn pain and distress", s:.93,
  n:"Repeatedly demonstrated during heel-prick procedures, and now part of routine care."},
 {t:"Touch can reduce pain", s:.86,
  n:"Gate control plus a large modern literature. The size of the effect varies a lot."},
 {t:"Who is touching you changes how much it helps", s:.80,
  n:"A partner's hand beats a stranger's, and the effect scales with relationship quality."},
 {t:"Slow, warm, moving touch on hairy skin is rated most pleasant", s:.78,
  n:"Robust as a group average. Individuals vary more than the curve suggests."},
 {t:"Touch reduces self-reported stress and anxiety", s:.72,
  n:"Consistent, but how people say they feel is the easiest thing in science to shift."},
 {t:"Massage produces lasting reductions in cortisol", s:.34,
  n:"Widely repeated in training. Meta-analysis has found the effect far smaller than claimed."},
 {t:"Interpersonal touch measurably raises oxytocin in blood", s:.26,
  n:"The most confidently stated and least secure claim in the field. Measurement is genuinely hard."}
];

const RULES = [
 {t:"Slower than feels natural — about a hand's width a second.",
  d:"One to ten centimetres a second is where the research clusters, and it is slower than most of us work by default."},
 {t:"Warmth seems to matter about as much as speed.",
  d:"Around skin temperature — hands, oil, room. Cold shifted every speed toward less pleasant, and technique did not appear to make up for it."},
 {t:"Hairy skin looks like the home ground, though not the only ground.",
  d:"Forearm, back, shoulders. The palm has some of these fibres after all — just fewer."},
 {t:"Still contact seems to count.",
  d:"Resting a hand is not a lesser version of stroking. It may be preferred to stroking done wrong."},
 {t:"Different intentions seem to want different systems.",
  d:"Fine detail wants a fingertip and hairless skin. Contact and comfort want a broad, slow, warm hand on hairy skin."},
 {t:"Averages describe populations, not the person on the table.",
  d:"The curve is an average across a lot of people. We would ask, watch and adjust rather than put a number on someone."},
 {t:"Saying what you are about to do matters more than we expected.",
  d:"You have access the social map normally saves for the people we are closest to. Saying it out loud seems to be how that stays safe rather than just allowed."},
 {t:"Describing the touch travels further than describing the mechanism.",
  d:"“Slow, warm, light, moving” is honest and checkable. “Activating your C-tactile fibres” goes beyond the evidence."},
 {t:"The hormone claims are the ones we would hold most loosely.",
  d:"That evidence is the thinnest thing here. The pain and comfort findings are steadier and need no help from it."},
 {t:"Most of the work is probably not being done by the fibres.",
  d:"Safety, consent, predictability and relationship. The fibres are the doorway, not the visit."}
];

const REFS = {
 vallbo99:{a:"Vallbo ÅB, Olausson H, Wessberg J", y:1999,
  t:"Unmyelinated afferents constitute a second system coding tactile stimuli of the human hairy skin",
  j:"Journal of Neurophysiology 81(6):2753–2763",
  u:"https://journals.physiology.org/doi/full/10.1152/jn.1999.81.6.2753"},
 olausson02:{a:"Olausson H, Lamarre Y, Backlund H, et al.", y:2002,
  t:"Unmyelinated tactile afferents signal touch and project to insular cortex",
  j:"Nature Neuroscience 5:900–904", u:"https://www.nature.com/articles/nn896"},
 loken09:{a:"Löken LS, Wessberg J, Morrison I, McGlone F, Olausson H", y:2009,
  t:"Coding of pleasant touch by unmyelinated afferents in humans",
  j:"Nature Neuroscience 12:547–548", u:"https://www.nature.com/articles/nn.2312"},
 ackerley14:{a:"Ackerley R, Backlund Wasling H, Liljencrantz J, et al.", y:2014,
  t:"Human C-tactile afferents are tuned to the temperature of a skin-stroking caress",
  j:"Journal of Neuroscience 34(8):2879–2883",
  u:"https://www.jneurosci.org/content/34/8/2879"},
 mcglone14:{a:"McGlone F, Wessberg J, Olausson H", y:2014,
  t:"Discriminative and affective touch: sensing and feeling",
  j:"Neuron 82(4):737–755",
  u:"https://www.cell.com/neuron/fulltext/S0896-6273(14)00387-0"},
 weinstein68:{a:"Weinstein S", y:1968,
  t:"Intensive and extensive aspects of tactile sensitivity as a function of body part, sex and laterality",
  j:"In: Kenshalo DR (ed.) The Skin Senses. Springfield: Thomas — still the source of the two-point figures everyone quotes",
  u:"https://en.wikipedia.org/wiki/Two-point_discrimination"},
 tong13:{a:"Tong J, Mao O, Goldreich D", y:2013,
  t:"Two-point orientation discrimination versus the traditional two-point test for tactile spatial acuity assessment",
  j:"Frontiers in Psychology 4:579",
  u:"https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3772339/"},
 melzack65:{a:"Melzack R, Wall PD", y:1965, t:"Pain mechanisms: a new theory",
  j:"Science 150(3699):971–979",
  u:"https://www.science.org/doi/10.1126/science.150.3699.971"},
 coan06:{a:"Coan JA, Schaefer HS, Davidson RJ", y:2006,
  t:"Lending a hand: social regulation of the neural response to threat",
  j:"Psychological Science 17(12):1032–1039",
  u:"https://journals.sagepub.com/doi/abs/10.1111/j.1467-9280.2006.01832.x"},
 goldstein18:{a:"Goldstein P, Weissman-Fogel I, Dumas G, Shamay-Tsoory SG", y:2018,
  t:"Brain-to-brain coupling during handholding is associated with pain reduction",
  j:"PNAS 115(11):E2528–E2537", u:"https://www.pnas.org/doi/10.1073/pnas.1703643115"},
 suvilehto15:{a:"Suvilehto JT, Glerean E, Dunbar RIM, Hari R, Nummenmaa L", y:2015,
  t:"Topography of social touching depends on emotional bonds between humans",
  j:"PNAS 112(45):13811–13816",
  u:"https://www.pnas.org/doi/abs/10.1073/pnas.1519231112"},
 watkins21:{a:"Watkins RH, Dione M, Ackerley R, Backlund Wasling H, Wessberg J, Löken LS", y:2021,
  t:"Evidence for sparse C-tactile afferent innervation of glabrous human hand skin",
  j:"Journal of Neurophysiology 125(1):232–237",
  u:"https://journals.physiology.org/doi/full/10.1152/jn.00587.2020"},
 case21:{a:"Case LK, Liljencrantz J, McCall MV, et al.", y:2021,
  t:"Pleasant deep pressure: expanding the social touch hypothesis",
  j:"Neuroscience 464:3–11", u:"https://pubmed.ncbi.nlm.nih.gov/33887384/"},
 ali23:{a:"Ali SH, Makdani AD, Cordero MI, et al.", y:2023,
  t:"Hold me or stroke me? Individual differences in static and dynamic affective touch",
  j:"PLoS ONE 18(5):e0281253",
  u:"https://pmc.ncbi.nlm.nih.gov/articles/PMC10204953/"},
 bendas21:{a:"Bendas J, Ree A, Pabel L, Sailer U, Croy I", y:2021,
  t:"Dynamics of affective habituation to touch differ on the group and individual level",
  j:"Neuroscience 464:44–52", u:"https://pubmed.ncbi.nlm.nih.gov/33359653/"},
 crucianelli22:{a:"Crucianelli L, Chancel M, Ehrsson HH", y:2022,
  t:"Modeling affective touch pleasantness across skin types at the individual level reveals a reliable and stable basic function",
  j:"Journal of Neurophysiology 128(6):1435–1452",
  u:"https://journals.physiology.org/doi/full/10.1152/jn.00179.2022"},
 schirmer23:{a:"Schirmer A, Croy I, Ackerley R", y:2023,
  t:"What are C-tactile afferents and how do they relate to “affective touch”?",
  j:"Neuroscience & Biobehavioral Reviews 151:105236",
  u:"https://www.sciencedirect.com/science/article/pii/S0149763423002270"},
 sailer22:{a:"Sailer U, Leknes S", y:2022, t:"Meaning makes touch affective",
  j:"Current Opinion in Behavioural Sciences 44:101099",
  u:"https://www.sciencedirect.com/science/article/pii/S2352154621001984"},
 schirmer22:{a:"Schirmer A, Croy I, Schweinberger SR", y:2022,
  t:"Social touch — a tool rather than a signal",
  j:"Current Opinion in Behavioural Sciences 44:101100",
  u:"https://www.sciencedirect.com/science/article/pii/S2352154621001996"},
 moyer11:{a:"Moyer CA, Seefeldt L, Mans ES, Jackson LM", y:2011,
  t:"Does massage therapy reduce cortisol? A comprehensive quantitative review",
  j:"Journal of Bodywork and Movement Therapies 15(1):3–14",
  u:"https://pubmed.ncbi.nlm.nih.gov/21147413/"},
 kidd23:{a:"Kidd T, Devine SL, Walker SC", y:2023,
  t:"Affective touch and regulation of stress responses",
  j:"Health Psychology Review 17(1):60–77",
  u:"https://www.tandfonline.com/doi/full/10.1080/17437199.2021.1980082"},
 morrison10:{a:"Morrison I, Löken LS, Olausson H", y:2010,
  t:"The skin as a social organ", j:"Experimental Brain Research 204(3):305–314",
  u:"https://link.springer.com/article/10.1007/s00221-009-2007-y"},
 suvilehto23:{a:"Suvilehto JT, Cekaite A, Morrison I", y:2023,
  t:"The why, who and how of social touch", j:"Nature Reviews Psychology 2:606–621",
  u:"https://www.nature.com/articles/s44159-023-00217-5"},
 standring:{a:"Cutaneous mechanoreceptors", y:"",
  t:"Merkel cells, Meissner corpuscles, Ruffini endings, Pacinian corpuscles and free nerve endings",
  j:"Standard anatomical description rather than a single source — each type is linked to its Wikipedia entry in that section",
  u:"https://en.wikipedia.org/wiki/Mechanoreceptor"}
};

/* the reading list shown above the references */
const FURTHER = [
 {id:"mcglone14", d:"The standard overview, free to read, and the source most people are quoting second-hand. Long, but the first half is very approachable."},
 {id:"morrison10", d:"The friendliest conceptual framing of why any of this might matter."},
 {id:"kidd23", d:"The bridge from nerve fibres to stress physiology, and the closest thing to a review written for people who do this for a living."},
 {id:"suvilehto23", d:"The widest recent view — who touches whom, where, and what for."}
];

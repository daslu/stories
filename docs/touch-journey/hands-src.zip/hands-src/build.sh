#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
OUT="${1:-dist/touch-journey.html}"
mkdir -p "$(dirname "$OUT")"
sed -n '1,/fonts.googleapis.com\/css2/p' index.html > "$OUT"
printf '<style>\n' >> "$OUT"; cat css/warm.css >> "$OUT"
printf '</style>\n</head>\n<body>\n<div class="wrap"></div>\n<script>\n' >> "$OUT"
cat js/journey.js js/scenes.js js/page.js >> "$OUT"
printf '\n</script>\n</body>\n</html>\n' >> "$OUT"
sed -n '/^<script>$/,/^<\/script>$/p' "$OUT" | sed '1d;$d' > /tmp/_tj.js
node --check /tmp/_tj.js; rm -f /tmp/_tj.js
echo "built $OUT ($(wc -c < "$OUT" | tr -d ' ') bytes) — JS parses"

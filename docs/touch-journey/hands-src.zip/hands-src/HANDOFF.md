# Handoff

Context for continuing *Touch is not one sense* — a reading journey for hands-on
practitioners. Written for whoever picks this up next, human or agent.

Read this before editing. The README covers how the code works; this covers
**what was decided, what was checked, and what is still wrong.**

---

## 1. What the page is trying to do

Teach hands-on practitioners — massage therapists, bodyworkers, physios, nurses,
somatic practitioners — what is actually established about touch, in a way that
survives contact with a sceptical client.

The audience constraint that shapes everything: **they have been taught things
that are not true**, usually with confidence, often in paid training. So the page
has to be warm without being credulous, and correct people without insulting the
work they have built a career on. That balance is the hardest thing here and it
is easy to lose in an edit.

Two failure modes to avoid in equal measure:

- **Debunking tone.** "Everything you learned is wrong." Untrue, unkind, and it
  loses the reader in a paragraph.
- **Motivated softness.** Letting a weak claim stand because it is nice. The
  oxytocin material is where this pressure is strongest.

The resolution the page settled on: *the felt experience is real; the mechanism
attributed to it often is not*. That sentence is the spine of parts three and
four.

---

## 2. Current state

Twelve stops in four parts, about thirty minutes, eleven figures of which nine
are interactive. 22 citations, 24 references, 17 Wikipedia links. Self-contained
— someone arriving cold from a link is oriented before the first stop.

```
Part one · the territory       two roads · the organ · how fine
Part two · the second system   found · the proof · a speed · a warmth
Part three · what touch does   pain · where · how sure
Part four · being honest       corrections · meaning
```

Build with `./build.sh`, audit with `node tools/check.js`. Both are cheap; run
the second after every content edit.

---

## 3. The editorial standard

These are not style preferences. Each one exists because breaking it produced a
real error during authoring.

**Every stop names its source before the reader meets the finding.** The `src`
block sits above the figure. An earlier draft had a citation card *after* the
prose, which meant meeting a claim before knowing where it came from.

**Every source carries an honest weight assessment**, in a sentence, not a badge:
*"Strong evidence, and a single case — you cannot arrange for a second patient."*
If you add a paper, write this line before you write the prose. It disciplines
what the prose is allowed to say.

**Say when researchers disagree.** Part four exists for this. The page is more
credible for containing "we had to take this back" than it would be without.

**Never let a measurement carry a practice conclusion it cannot support.** See
§5 — this is the error class that got furthest.

**Do not describe chrome that is conditional on viewport.** The contents rail
only renders above 1340px. `check.js` fails on the phrase "contents rail".

**Interface text must track state.** A hint that says "tap to take the hand away"
has to change when the hand is away.

---

## 4. What is verified, and how well

Everything below was checked against sources during authoring. Confidence varies
and the page reflects that; **do not flatten it.**

| Claim | Confidence | Note |
|---|---|---|
| Two systems, fast myelinated and slow unmyelinated | solid | Vallbo 1999, replicated for 25 years |
| CT signal arrives ~1 s behind | solid enough | ~1 m/s conduction over a forearm; page says "something like a second behind" |
| 27 of 38 units were low-threshold | **exact, but easy to misuse** | those units were *selected* for answering gentle touch — it is not a prevalence figure. The page says so explicitly. Do not simplify this back. |
| Patient could feel brushing, activated insula not S1 | solid | Olausson 2002, single case |
| CT firing peaks 1–10 cm/s, tracks pleasantness | solid at group level | individual variation is large — part four says so |
| Spontaneous caress speed | **contradicted** | measured spontaneous stroking runs *faster* than the CT optimum. An earlier draft claimed the opposite. The caveat is in the text; keep it. |
| Tuned to ~32 °C; all speeds rated better at skin temperature | good | Ackerley 2014, small study |
| Two-point thresholds: fingertip 2–3 mm … back ~39 mm | ranking solid, numbers soft | Weinstein 1968; the test itself is criticised (Tong 2013) |
| Gate control | foundational, much revised | do not present the 1965 mechanism as current detail |
| Handholding reduces threat response; partner > stranger | good, small studies | Coan 2006, Goldstein 2018 |
| Permitted-touch area tracks bond strength, n=1368, 5 countries | solid | self-report; the page says so |
| Sparse CT innervation of glabrous hand skin | newer, revises the old story | Watkins 2021 — the "none in the palm" line is retired |
| Only ~34% of "affective touch" papers mention CT afferents | exact | Schirmer 2023 |
| Massage lowers cortisol | **weak** | Moyer 2011 found it far smaller than claimed |
| Touch raises blood oxytocin | **weakest thing on the page** | sits at 0.26 in the CLAIMS figure, deliberately |

The `CLAIMS` figure encodes a judgement, not effect sizes, and the caption says
so. Its value is the **gradient** — physical claims strong, hormone claims weak.
`check.js` fails if the ordering breaks or the weakest claim drifts above 0.4.

---

## 5. Error classes that actually occurred

Worth knowing, because they will recur.

**A correct measurement carrying a conclusion it cannot support.** The worst one,
and it survived several drafts:

> "So fine, detailed work on a back is largely wasted as information — the
> resolution is not there."

Two-point discrimination measures whether skin resolves two *simultaneous*
points. It says nothing about whether precise placement matters, because
(a) locating a single contact is more accurate than telling two apart, (b) pressure
reaches muscle, fascia and joints, which have their own sensory supply, and
(c) in manual work the precision often matters most to the *practitioner*, whose
fingertips resolve at 2–3 mm. A reader who works with tissue rather than skin
spotted it immediately. **Rule: when a sentence moves from what was measured to
what you should therefore do, re-read it.**

**Stale counts after the page grew.** "Six stops" survived an expansion to twelve.
`check.js` now cross-checks stated counts against the arrays.

**A title that stopped matching the scope.** *"Your hands are talking to a second
nervous system"* was right for seven stops about CT afferents and misleading once
part three existed. If you add sections, check the title still covers them.

**Assumed prior training.** "The fast road is what you learned about" excludes
exactly the reader the page is for.

**Interface text that did not track state.** The gate hint.

**A silently failed edit.** The send-a-touch animation was inserted against an
anchor comment that no longer existed. The build passed `node --check` because
the file was still valid JavaScript — it just did not contain the function. Only
clicking the button found it. **Lesson: a green build is not evidence a feature
exists.**

---

## 6. Rough edges

- **`W = 860` is assumed** in `scenes.js` and again in the animation code in
  `page.js` (`sendTouch`, `stroke`). Changing it needs both.
- **The stroking dot's travel span** in `stroke()` is hand-tuned to the arm shape.
  If you change `arm()` or the speed-scene margins, re-check it.
- **No dark theme**, on purpose. Adding one means a second palette for the soft
  fills, which mostly rely on warmth to read at all.
- **Body zones in the topography figure are invented** — a simplification of the
  published maps. The bond-against-area bars beside them are the paper's actual
  finding. Do not present the body map as data.
- **The meaning figure's verdict words** (welcome / endured / intrusive) are
  illustrative. No study assigns them. Caption says so; keep it.
- **`check.js` cannot see layout.** SVG overflow, label collisions and stale
  helper text still need a browser. During authoring these were caught with
  puppeteer: load the page, click every control, screenshot, and assert node
  boxes do not intersect. Worth porting into `tools/` if you keep extending.
- **Long-run link rot.** Two dozen external links. No checker for them.

---

## 7. Ideas considered and not built

Not rejected — just not yet, with the reason, so you can weigh them.

**A "test yourself" two-point widget** that asks the reader to actually try it and
record what they found. The acuity stop already invites this in prose. A recorded
result would make it stick, but it needs storage and the page is deliberately
stateless.

**Self-touch versus other-touch.** Why you cannot tickle yourself — prediction
cancels the sensation. Genuinely interesting, directly relevant to why a
practitioner's hand does something the client's own cannot, and there is decent
work behind it (Blakemore, Wolpert & Frith). The best single omission to fix.

**Touch across development.** Kangaroo care, preterm skin-to-skin, Feldman's
follow-up work. Strong evidence, high emotional weight, and it would broaden the
audience to midwives and neonatal staff. Left out only for length.

**Touch deprivation.** Topical and poorly evidenced. Would need care.

**Clinical populations** — altered affective touch in anorexia nervosa, autism.
Real literature, but it risks the page being read as diagnostic.

**Itch, temperature and proprioception** as siblings of touch. Would complete
part one, at the cost of the page's focus.

**Spaced repetition or a quiz.** On the design checklist, never built. The
predict-then-reveal in the claims figure is the only retrieval practice present.

---

## 8. The research landscape, beyond what made it in

If you extend, these are the reference points:

- **McGlone, Wessberg & Olausson (2014), *Neuron*** — the standard overview, free
  to read, and the source most second-hand accounts are quoting. Start here.
- **Suvilehto, Cekaite & Morrison (2023), *Nature Reviews Psychology*** — the
  widest recent view of social touch.
- **Kidd, Devine & Walker (2023), *Health Psychology Review*** — the bridge from
  fibres to stress physiology, and the closest thing to a review written for
  people who do this for a living.
- **Schirmer, Croy & Ackerley (2023)** — the field auditing itself. The single
  most important corrective, and the reason part four exists.
- **Morrison, Löken & Olausson (2010), "The skin as a social organ"** — the
  friendliest conceptual framing.

The field's own open questions, as of writing: how much CT afferents contribute
relative to Aβ in ordinary perception; whether the social-touch hypothesis
generalises beyond stroking; how much individual variation is real signal versus
measurement noise; and whether "affective touch" as a construct should be pinned
to a fibre class at all. That last one is live and unresolved.

---

## 9. If you change one thing, change this

The page currently ends on the strongest note it has — *the fibre is not the
feeling*, meaning is doing most of the work, which is what a good practitioner
already knows. Do not bury that under new material. If part five appears, it
should come **before** "meaning", not after.

#!/usr/bin/env node
/* tools/check.js — content audit. No dependencies, no browser.
 *
 *   node tools/check.js
 *
 * Catches the failure modes this page has actually hit during authoring.
 * Run it after any edit to journey.js. Exit code 1 if anything is wrong,
 * so it can go in a pre-commit hook.
 *
 * What it does NOT catch (needs a browser — see HANDOFF.md):
 *   · figures whose SVG overflows its viewBox
 *   · helper text that fails to update when its control toggles
 *   · anything about layout
 */

const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.join(__dirname, "..");
const read = f => fs.readFileSync(path.join(root, f), "utf8");

/* load the content layer in isolation */
const ctx = vm.createContext({});
vm.runInContext(read("js/journey.js"), ctx, { filename: "journey.js" });
const { HERO, ABOUT, STOPS, REVISIONS, CLAIMS, RULES, REFS, FURTHER } =
  vm.runInContext("({HERO,ABOUT,STOPS,REVISIONS,CLAIMS,RULES,REFS,FURTHER})", ctx);

const problems = [];
const notes = [];
const fail = m => problems.push(m);
const note = m => notes.push(m);

/* every string a reader can see */
const prose = [];
const collect = (label, s) => { if (typeof s === "string") prose.push([label, s]); };
collect("hero.stand", HERO.stand);
collect("hero.title", HERO.title);
ABOUT.forEach((a, i) => collect(`about[${i}].v`, a.v));
STOPS.forEach(s => {
  ["title", "lead", "body", "hands"].forEach(k => collect(`${s.id}.${k}`, s[k]));
  if (s.src) collect(`${s.id}.src`, s.src.line);
});
REVISIONS.forEach((r, i) => { collect(`rev[${i}].old`, r.old); collect(`rev[${i}].neu`, r.neu); });
CLAIMS.forEach((c, i) => { collect(`claim[${i}].t`, c.t); collect(`claim[${i}].n`, c.n); });
RULES.forEach((r, i) => { collect(`rule[${i}].t`, r.t); collect(`rule[${i}].d`, r.d); });

/* ── 1. citations resolve ─────────────────────────────────────── */
const cited = new Set();
prose.forEach(([where, s]) => {
  (s.match(/\[ref:[^\]]*\]/g) || []).forEach(tok => {
    const id = tok.slice(5, -1);
    if (!/^[a-z][a-z0-9]*$/.test(id)) fail(`malformed citation ${tok} in ${where}`);
    else if (!REFS[id]) fail(`citation [ref:${id}] in ${where} has no entry in REFS`);
    else cited.add(id);
  });
});
Object.keys(REFS).forEach(id => {
  const inFurther = FURTHER.some(f => f.id === id);
  if (!cited.has(id) && !inFurther)
    note(`REFS.${id} is defined but never cited and not in FURTHER — dead entry?`);
});
FURTHER.forEach(f => { if (!REFS[f.id]) fail(`FURTHER lists "${f.id}", which is not in REFS`); });

/* ── 2. wikipedia markup is well formed ───────────────────────── */
prose.forEach(([where, s]) => {
  (s.match(/\{\{[^}]*\}\}/g) || []).forEach(tok => {
    const inner = tok.slice(2, -2);
    if (!inner.includes("|")) fail(`wiki link ${tok} in ${where} needs Page|text`);
    else {
      const [page, text] = inner.split("|");
      if (!page.trim()) fail(`empty wiki page in ${where}`);
      if (!text || !text.trim()) fail(`empty wiki link text in ${where}`);
    }
  });
  /* an unbalanced brace would silently render as literal text */
  const opens = (s.match(/\{\{/g) || []).length, closes = (s.match(/\}\}/g) || []).length;
  if (opens !== closes) fail(`unbalanced {{ }} in ${where}`);
});

/* ── 3. structure ─────────────────────────────────────────────── */
const seen = new Set(), navs = new Set();
/* a scene is valid if scenes.js maps it to a renderer, or page.js handles it
   directly in the sceneFor switch (the card-based ones do) */
const known = new Set();
(read("js/scenes.js").match(/(\w+)\s*:\s*scene[A-Z]\w*/g) || [])
  .forEach(m => known.add(m.split(":")[0].trim()));
(read("js/page.js").match(/case\s+"(\w+)":/g) || [])
  .forEach(m => known.add(m.match(/"(\w+)"/)[1]));
STOPS.forEach(s => {
  ["id", "nav", "title", "lead", "scene", "body"].forEach(k => {
    if (!s[k]) fail(`stop "${s.id || "?"}" is missing ${k}`);
  });
  if (seen.has(s.id)) fail(`duplicate stop id "${s.id}"`);
  seen.add(s.id);
  if (navs.has(s.nav)) fail(`two stops share the nav label "${s.nav}"`);
  navs.add(s.nav);
  if (s.scene && !known.has(s.scene))
    fail(`stop "${s.id}" wants scene "${s.scene}", which is not registered in SCENES`);
  if (!s.hands) note(`stop "${s.id}" has no "for your hands" takeaway`);
});

/* ── 4. claims figure keeps its shape ─────────────────────────── */
const sorted = [...CLAIMS].every((c, i, a) => i === 0 || a[i - 1].s >= c.s);
if (!sorted) fail("CLAIMS is not in descending order of confidence — the figure reads as a gradient and depends on it");
if (CLAIMS[CLAIMS.length - 1].s > 0.4)
  fail("the weakest claim has drifted above 0.4 — the point of the figure is that the hormone claims sit low");

/* ── 5. counts stated in prose match reality ──────────────────── */
const allText = prose.map(p => p[1]).join(" ");
const words = {twelve:12, eleven:11, ten:10, nine:9, eight:8, seven:7, six:6, five:5, four:4, three:3, two:2};
const stopClaim = allText.match(/\b(\w+) short stops\b/);
if (stopClaim && words[stopClaim[1].toLowerCase()] !== STOPS.length)
  fail(`the text says "${stopClaim[1]} short stops" but there are ${STOPS.length}`);
const ruleClaim = allText.match(/\b(\w+) things, in rough order\b/);
if (ruleClaim && words[ruleClaim[1].toLowerCase()] !== RULES.length)
  note(`the rules intro says "${ruleClaim[1]}" but RULES has ${RULES.length} — check page.js too`);

/* ── 6. phrasings that have caused trouble before ─────────────── */
const risky = [
  [/\bproves?\b/i, "'proves' — almost nothing here proves anything"],
  [/\bwhat you learned\b/i, "assumes the reader was taught anatomy"],
  [/\bas you know\b/i, "assumes prior knowledge"],
  [/\bobviously\b/i, "'obviously'"],
  [/\bproportional to\b/i, "'proportional to' — check the paper actually says proportional"],
  [/\bcontents rail\b/i, "describes chrome that is hidden below 1340px"],
  [/\bis wasted\b/i, "a measurement carrying a practice conclusion — see HANDOFF.md"]
];
prose.forEach(([where, s]) => risky.forEach(([re, why]) => {
  if (re.test(s)) fail(`${where}: ${why}`);
}));

/* ── report ───────────────────────────────────────────────────── */
console.log(`stops ${STOPS.length} · references ${Object.keys(REFS).length} · cited ${cited.size} · ` +
  `wiki links ${(allText.match(/\{\{/g) || []).length} · claims ${CLAIMS.length} · rules ${RULES.length}`);
notes.forEach(n => console.log("  note  " + n));
if (problems.length) {
  problems.forEach(p => console.log("  FAIL  " + p));
  console.log(`\n${problems.length} problem${problems.length > 1 ? "s" : ""}.`);
  process.exit(1);
}
console.log("\nall checks pass.");

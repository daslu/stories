# Handoff

Context for continuing *Touch is not one sense* — a reading journey for hands-on
practitioners. Written for whoever picks this up next, human or agent.

Read this before editing. The README covers how the code works; this covers
**what was decided, what was checked, and what is still wrong.**
[RESEARCH.md](RESEARCH.md) covers **what could go in next** — candidate papers
checked against source, each with the figure it could carry and the error it
invites. Sections 7 and 8 below are its starting point.

---

## 1. What the page is trying to do

Teach hands-on practitioners — massage therapists, bodyworkers, physios, nurses,
somatic practitioners — what is actually established about touch, in a way that
survives contact with a sceptical client.

The audience constraint that shapes everything: **they have been taught things
that are not true**, usually with confidence, often in paid training. So the page
has to be warm without being credulous, and correct people without insulting the
work they have built a career on. That balance is the hardest thing here and it
is easy to lose in an edit.

Two failure modes to avoid in equal measure:

- **Debunking tone.** "Everything you learned is wrong." Untrue, unkind, and it
  loses the reader in a paragraph.
- **Motivated softness.** Letting a weak claim stand because it is nice. The
  oxytocin material is where this pressure is strongest.

The resolution the page settled on: *the felt experience is real; the mechanism
attributed to it often is not*. That sentence is the spine of parts three and
four.

---

## 2. Current state

Twelve stops in four parts, about thirty minutes, twelve figures of which eleven
are interactive (only *the patient* is static). 22 citations, 24 references, 17 Wikipedia links. Self-contained
— someone arriving cold from a link is oriented before the first stop.

```
Part one · the territory       two roads · the organ · how fine
Part two · the second system   found · the proof · a speed · a warmth
Part three · what touch does   pain · where · how sure
Part four · being honest       corrections · meaning
```

Build with `./build.sh`, audit content with `node tools/check.js`, audit layout
with `node tools/layout-check.js`. All three are cheap; run both checkers after
every edit.

**The page has two layouts.** Scenes are drawn against `W`: 860 above 820px, 420
at or below it. Every scene branches on `NARROW`, and `page.js` redraws when the
media query flips. README §*Two layouts* has the reasoning.

### The most recent pass (2026-09-06)

- **Twelve narrow layouts added.** The page had never worked on a phone: at
  `W=860` on a 390px screen the scale factor is 0.36, so a 13u label rendered at
  **4.7px**. It is 11.1px now, and 8.9px at 320px.
- **Label colour restored.** Every `fill` attribute on a classed `<text>` had
  been dead for the life of the page — see §5.
- **Voice changed.** Instruction became observation, the narrator is **we**, and
  purpose language was removed — see §3.
- **Four layout bugs and two dead code paths fixed**, all pre-existing.

---

## 3. The editorial standard

These are not style preferences. Each one exists because breaking it produced a
real error during authoring.

**Every stop names its source before the reader meets the finding.** The `src`
block sits above the figure. An earlier draft had a citation card *after* the
prose, which meant meeting a claim before knowing where it came from.

**Every source carries an honest weight assessment**, in a sentence, not a badge:
*"Strong evidence, and a single case — you cannot arrange for a second patient."*
If you add a paper, write this line before you write the prose. It disciplines
what the prose is allowed to say.

**Say when researchers disagree.** Part four exists for this. The page is more
credible for containing "we had to take this back" than it would be without.

**Never let a measurement carry a practice conclusion it cannot support.** See
§5 — this is the error class that got furthest.

**Do not describe chrome that is conditional on viewport.** The contents rail
only renders above 1340px. `check.js` fails on the phrase "contents rail".

**Interface text must track state.** A hint that says "tap to take the hand away"
has to change when the hand is away.

**The narrator is "we", and it observes rather than instructs.** The closing list
used to be ten imperatives under "What to actually do with this" — *Slow down*,
*Warm your hands*, *Drop the hormone claims*. It is now "What we would carry back
into the room", and the entries report what the reading suggested rather than
telling the reader what to do. Same evidence, same order; different standing. The
page is a record of what two readers found, not a protocol.

**Humility is calibrated, not uniform.** This matters more than it sounds. The
temptation when softening tone is to hedge everything equally, which destroys the
single most useful thing the page does — separating a replicated finding from a
shaky one. Stay confident where the evidence is (two systems, the speed tuning,
the gate); be openly unsure only where it is thin (oxytocin, cortisol). Rule 8
still says flatly that "Activating your C-tactile fibres" goes beyond the
evidence, and should.

**Nothing biological is described as having a purpose.** Not *what each system is
for*, not *seems to exist to*, not *in the business of*. The page says what things
do and what they respond to, because that is what the studies measured. The 1999
paper found a second system and did not know **what it was doing** — that is a
statement about observation, not about a purpose still to be discovered. Human
purpose is fine and stays: "Who it is for", the practitioner's "role, for a
purpose", and "what you believe it is for" — the last one is the whole subject of
the final stop.

**Plain words, except where the real name is the point.** Written for readers with
no science background, so: *hairless* not *glabrous*, *nerve disease* not
*neuropathy*, *how common they are* not *a prevalence figure*, *checking their own
published work* not *auditing their own literature*. The exception is a term the
page deliberately introduces and links to Wikipedia — *myelin*, *mechanoreceptors*,
*two-point discrimination*, *microneurography*, *affective touch*. Those stay, with
a plain gloss beside them. Paper titles and journal names in `REFS` are quoted
records and are never reworded.

---

## 4. What is verified, and how well

Everything below was checked against sources during authoring. Confidence varies
and the page reflects that; **do not flatten it.**

| Claim | Confidence | Note |
|---|---|---|
| Two systems, fast myelinated and slow unmyelinated | solid | Vallbo 1999, replicated for 25 years |
| CT signal arrives ~1 s behind | solid enough | ~1 m/s conduction over a forearm; page says "something like a second behind" |
| 27 of 38 units were low-threshold | **exact, but easy to misuse** | those units were *selected* for answering gentle touch — it is not a prevalence figure. The page says so explicitly. Do not simplify this back. |
| Patient could feel brushing, activated insula not S1 | solid | Olausson 2002, single case |
| CT firing peaks 1–10 cm/s, tracks pleasantness | solid at group level | individual variation is large — part four says so |
| Spontaneous caress speed | **contradicted** | measured spontaneous stroking runs *faster* than the CT optimum. An earlier draft claimed the opposite. The caveat is in the text; keep it. |
| Tuned to ~32 °C; all speeds rated better at skin temperature | good | Ackerley 2014, small study |
| Two-point thresholds: fingertip 2–3 mm … back ~39 mm | ranking solid, numbers soft | Weinstein 1968; the test itself is criticised (Tong 2013) |
| Gate control | foundational, much revised | do not present the 1965 mechanism as current detail |
| Handholding reduces threat response; partner > stranger | good, small studies | Coan 2006, Goldstein 2018 |
| Permitted-touch area tracks bond strength, n=1368, 5 countries | solid | self-report; the page says so |
| Sparse CT innervation of glabrous hand skin | newer, revises the old story | Watkins 2021 — the "none in the palm" line is retired |
| Only ~34% of "affective touch" papers mention CT afferents | exact | Schirmer 2023 |
| Massage lowers cortisol | **weak** | Moyer 2011 found it far smaller than claimed |
| Touch raises blood oxytocin | **weakest thing on the page** | sits at 0.26 in the CLAIMS figure, deliberately |

The `CLAIMS` figure encodes a judgement, not effect sizes, and the caption says
so. Its value is the **gradient** — physical claims strong, hormone claims weak.
`check.js` fails if the ordering breaks or the weakest claim drifts above 0.4.

---

## 5. Error classes that actually occurred

Worth knowing, because they will recur.

**A CSS rule silently beating a presentation attribute.** Every
`fill="var(--blue)"` on a `<text>` that also carried a class was dead, because
`.lab`/`.sm`/`.xs`/`.big` all set `fill` and presentation attributes sit *below*
author CSS in the cascade. For most of this page's life no label was ever blue or
clay — measured, all 14 class+fill combinations computed to the class colour —
while the source read as though the two-colour scheme was working. Fixed by
moving them to inline `style="fill:…"`, which does outrank a class. **If you add
a coloured label, use `style`, not the attribute.**

**A duplicate declaration silently shadowing the real one.** `scenes.js` defined
`sceneContext` twice; the later definition won, so the earlier doorway
illustration never rendered at all. `page.js` had a second, unreachable
`case "claims"`. This is legal JavaScript — neither `node --check` nor
`check.js` will tell you. It is also where the "eleven figures / twelve items"
confusion in the README came from.

**Selector specificity beating a later rule.** A mobile `figure { margin-left: … }`
did nothing, because `.wide` zeroes those margins at ≤820px and a class outranks
an element selector. It has to be `figure.wide`. Nothing errors; the rule is just
ignored.

**A checker that under-reports is worse than no checker.** The first version of
the layout probe inspected only `<text>` and wrapped `getBBox()` in a try/catch
returning a zero box. It reported the `meaning` figure **clean** while most of
that figure sat off-canvas. `layout-check.js` now walks every drawable element
and lets a throw surface.

**A correct measurement carrying a conclusion it cannot support.** The worst one,
and it survived several drafts:

> "So fine, detailed work on a back is largely wasted as information — the
> resolution is not there."

Two-point discrimination measures whether skin resolves two *simultaneous*
points. It says nothing about whether precise placement matters, because
(a) locating a single contact is more accurate than telling two apart, (b) pressure
reaches muscle, fascia and joints, which have their own sensory supply, and
(c) in manual work the precision often matters most to the *practitioner*, whose
fingertips resolve at 2–3 mm. A reader who works with tissue rather than skin
spotted it immediately. **Rule: when a sentence moves from what was measured to
what you should therefore do, re-read it.**

**Stale counts after the page grew.** "Six stops" survived an expansion to twelve.
`check.js` now cross-checks stated counts against the arrays.

**A title that stopped matching the scope.** *"Your hands are talking to a second
nervous system"* was right for seven stops about CT afferents and misleading once
part three existed. If you add sections, check the title still covers them.

**Assumed prior training.** "The fast road is what you learned about" excludes
exactly the reader the page is for.

**Interface text that did not track state.** The gate hint.

**A silently failed edit.** The send-a-touch animation was inserted against an
anchor comment that no longer existed. The build passed `node --check` because
the file was still valid JavaScript — it just did not contain the function. Only
clicking the button found it. **Lesson: a green build is not evidence a feature
exists.**

---

## 6. Rough edges

- **`W` is two values now, not one** — 860 wide, 420 narrow, switched by
  `layout()` in `scenes.js`. A new scene needs a `NARROW` branch; without one it
  is drawn for an 860 canvas inside a 420 one and most of it lands off-screen.
  `layout-check.js` fails loudly on this, which is the point of it.
- **The stroking dot's travel span** comes from `STROKE_GEOM`, which `sceneSpeed`
  sets as it draws, because the arm sits in a different place in each layout.
  `stroke()` in `page.js` reads it. If you change `arm()` or the speed-scene
  margins, that object is what to re-check.
- **No dark theme**, on purpose. Adding one means a second palette for the soft
  fills, which mostly rely on warmth to read at all.
- **Body zones in the topography figure are invented** — a simplification of the
  published maps. The bond-against-area bars beside them are the paper's actual
  finding. Do not present the body map as data.
- **The meaning figure's verdict words** (welcome / endured / intrusive) are
  illustrative. No study assigns them. Caption says so; keep it.
- **`check.js` still cannot see layout** — that is what `tools/layout-check.js`
  is for, and it is now written. It renders the built page in headless Chrome at
  six widths, clicks all 32 controls, and asserts that nothing leaves its viewBox
  and no two labels overlap. Geometry comes from `getBBox()`, so results are
  independent of display scale. Exit 1 on failure. It needs `chrome` or
  `chromium` on PATH and skips quietly if neither is there. Two notes if you
  extend it: headless Chrome will not size its window below ~500px, so the page
  is loaded in an exact-width iframe, and that iframe needs
  `--allow-file-access-from-files` to be readable over `file://`.
- **The two-point figure is not drawn to scale**, although its caption used to
  claim it was. Measured: the dots render at 1.27x life size at 320px and 2.45x
  at 1100px, against a true 3.78 CSS px per mm. The caption now says "drawn
  larger than life … the proportions between body parts are the real ones",
  which is honest. But the figure still cannot be checked against a real ruler,
  and "test it on yourself in a minute" is the promise it is making. Genuine 1:1
  is feasible — 2.5mm is 9.4px and a 45mm calf 170px, both fit a phone — and
  would make that promise real. **Left undone deliberately: it is a content
  decision, not a bug.**
- **Long-run link rot.** Two dozen external links. No checker for them.

---

## 7. Ideas considered and not built

Not rejected — just not yet, with the reason, so you can weigh them.

**A "test yourself" two-point widget** that asks the reader to actually try it and
record what they found. The acuity stop already invites this in prose. A recorded
result would make it stick, but it needs storage and the page is deliberately
stateless.

**Self-touch versus other-touch.** Why you cannot tickle yourself — prediction
cancels the sensation. Genuinely interesting, directly relevant to why a
practitioner's hand does something the client's own cannot, and there is decent
work behind it (Blakemore, Wolpert & Frith). The best single omission to fix.

**Touch across development.** Kangaroo care, preterm skin-to-skin, Feldman's
follow-up work. Strong evidence, high emotional weight, and it would broaden the
audience to midwives and neonatal staff. Left out only for length.

**Touch deprivation.** Topical and poorly evidenced. Would need care.

**Clinical populations** — altered affective touch in anorexia nervosa, autism.
Real literature, but it risks the page being read as diagnostic.

**Itch, temperature and proprioception** as siblings of touch. Would complete
part one, at the cost of the page's focus.

**Spaced repetition or a quiz.** On the design checklist, never built. The
predict-then-reveal in the claims figure is the only retrieval practice present.

---

## 8. The research landscape, beyond what made it in

Extended in [RESEARCH.md](RESEARCH.md), which assesses fifteen further texts for
fit and for whether they could carry a figure. Two things there change what is
written below: a 2024 meta-analysis (Packheiser et al., 137 studies, 12,966
people) now sits above everything in this list for the claims in part three, and
the newest primary finding on CT afferents is 2025, not 2023.

If you extend, these are the reference points:

- **McGlone, Wessberg & Olausson (2014), *Neuron*** — the standard overview, free
  to read, and the source most second-hand accounts are quoting. Start here.
- **Suvilehto, Cekaite & Morrison (2023), *Nature Reviews Psychology*** — the
  widest recent view of social touch.
- **Kidd, Devine & Walker (2023), *Health Psychology Review*** — the bridge from
  fibres to stress physiology, and the closest thing to a review written for
  people who do this for a living.
- **Schirmer, Croy & Ackerley (2023)** — the field auditing itself. The single
  most important corrective, and the reason part four exists.
- **Morrison, Löken & Olausson (2010), "The skin as a social organ"** — the
  friendliest conceptual framing.

The field's own open questions, as of writing: how much CT afferents contribute
relative to Aβ in ordinary perception; whether the social-touch hypothesis
generalises beyond stroking; how much individual variation is real signal versus
measurement noise; and whether "affective touch" as a construct should be pinned
to a fibre class at all. That last one is live and unresolved.

---

## 9. If you change one thing, change this

The page currently ends on the strongest note it has — *the fibre is not the
feeling*, meaning is doing most of the work, which is what a good practitioner
already knows. Do not bury that under new material. If part five appears, it
should come **before** "meaning", not after.
